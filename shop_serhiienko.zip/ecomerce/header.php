<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Store</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/styles.css">

<!-- Favicon -->
<link rel="icon" sizes="192x192" href="img/Graphico.png">
<link rel="apple-touch-icon" sizes="180x180" href="img/Graphico.png">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css"> 

<!-- Customized Bootstrap Stylesheet -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<script defer src = "https://code.jquery.com/jquery-3.7.0.js"> </script>
<script defer src = "https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"> </script>
<script defer src = "https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"> </script>

<div class="container-fluid">
      <div class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex">
            <div class="col-lg-4">
                <a href="index.php" class="text-decoration-none">
				 <span class="h1 text-uppercase text-primary bg-light px-2">Online</span>
                 <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Store</span>
                </a>
            </div>
            <div class="col-lg-4 col-6 text-left">
                <form action="https://www.google.com/search"  method="get" class="search-bar">
                    <div class="input-group">
                    <input type="text" class="form-control" placeholder="What are you looking for?" name="q">
                                <div class="input-group-append">
                                    <button class="btn btn-primary">Search</button>
                                </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-4 col-6 text-right">
            <p class="m-0">Infoline</p>
            <h5 class="m-0">+421 333 6789</h5>
            </div>
</div></div>



</head>
<body>
    <?php include 'menu.php'; ?>
    <div class="container">
