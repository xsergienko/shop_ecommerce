<?php include 'header.php'; ?>
<?php
session_start();
include 'db.php';
$category = isset($_GET['category']) ? $_GET['category'] : '';
if (isset($_SESSION['userid'])){
$id = $_SESSION['userid'];}
// Формируем запрос SQL с учетом выбранной категории
$sql = "SELECT * FROM products";
if (!empty($category)) {
    $sql .= " WHERE category = '$category'";
}
$result = $conn->query($sql);

// Проверка на успешное выполнение запроса и обработка ошибок
function executeQuery($conn, $query) {
    $result = $conn->query($query);
    if (!$result) {
        die("Query failed: " . $conn->error);
    }
    return $result;
}
if (isset($_SESSION['userid'])){
// Общее количество заказов
$sql_total_orders = "SELECT COUNT(*) as total_orders FROM order_items WHERE user_id = $id";
$result_total_orders = executeQuery($conn, $sql_total_orders);
$row_total_orders = $result_total_orders->fetch_assoc();
$total_orders = $row_total_orders['total_orders'];
}
?>

<!-- Форма для выбора категории -->
<form method="get" action="view_products.php">
    <div class="form-group mt-3">
        <label for="category">Filter by category:</label>
        <select class="form-control" id="category" name="category" onchange="this.form.submit()">
            <option value="">All</option>
            <option value="Electro" <?php if ($category == 'Electro') echo 'selected'; ?>>Electro</option>
            <option value="Nábytok" <?php if ($category == 'Nábytok') echo 'selected'; ?>>Nábytok</option>
            <option value="Oblečenie" <?php if ($category == 'Oblečenie') echo 'selected'; ?>>Oblečenie</option>
            <option value="Hobby" <?php if ($category == 'Hobby') echo 'selected'; ?>>Hobby</option>
        </select>
    </div>
</form>

<?php
if ($result->num_rows > 0) {
    echo "<form method='post' action='add_to_cart.php'>";
    echo "<table class='table'>";
    echo "<thead><tr><th>Name</th><th>Category</th><th>Description</th><th>Price (€)</th>";
     if (isset($_SESSION['userid']) && $total_orders < 5) {
        echo "<th>Quantity</th><th></th></tr>";
     }
    echo "</thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['name']}</td>";
        echo "<td>{$row['category']}</td>";
        echo "<td>{$row['description']}</td>";
        echo "<td>{$row['price']}</td>";
        if (isset($_SESSION['userid']) && $total_orders < 5) {
           
                echo "<td><input type='number' name='quantity[{$row['id']}]' min='1' max='99' value='1' class='form-control' required></td>";
                echo "<td><button type='submit' name='add_to_cart' value='{$row['id']}' class='btn btn-primary'>Add to Cart</button></td>";
        }
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
    echo "</form>";
} else {
    echo "No products found.";
}

$conn->close();
?>

<?php include 'footer.php'; ?>
