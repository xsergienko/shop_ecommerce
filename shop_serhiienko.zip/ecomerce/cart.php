<?php include 'header.php'; ?>
<?php
session_start();
include 'db.php';

// Проверка авторизации пользователя
if (!isset($_SESSION['userid'])) {
    // Если пользователь не авторизован, перенаправляем его на страницу входа
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['userid'];

// Проверяем, был ли отправлен запрос на удаление товара
if (isset($_GET['delete_item'])) {
    $item_id = $_GET['delete_item'];

    // Подготовленный запрос для удаления товара из корзины
    $stmt = $conn->prepare("DELETE FROM order_items WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $item_id, $user_id);
    $stmt->execute();
    $stmt->close();

    // Перенаправление на текущую страницу для обновления корзины
    header("Location: cart.php");
    exit();
}

// Запрос для получения товаров в корзине текущего пользователя
$sql = "SELECT order_items.id, products.name, products.price, order_items.quantity
        FROM order_items
        INNER JOIN products ON order_items.product_id = products.id
        WHERE order_items.user_id = $user_id";
$result = $conn->query($sql);
?>

<div class="container mt-3">
    <h2>Your Cart</h2>
    <?php if ($result->num_rows > 0) : ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Price (€)</th>
                    <th>Quantity</th>
                    <th>Total (€)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total_price = 0;
                while ($row = $result->fetch_assoc()) :
                    $total = $row['price'] * $row['quantity'];
                    $total_price += $total;
                ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo number_format($total, 2); ?></td>
                        <td><a href="cart.php?delete_item=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <h4>Total Price: <?php echo number_format($total_price, 2); ?>€<h4>
    <?php else : ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>

 <div class="container text-center">
  <div class="row">     
    <div class="col-md-12">
        <a href="products_pdf.php" class="btn btn-lg btn-primary" style="margin: 10px;">Download PDF</a>
        <a href="products_xlsx.php" class="btn btn-lg btn-primary" style="margin: 10px;">Download XLSX</a>
    </div>
  </div>
</div>

</div>

<?php include 'footer.php'; ?>
