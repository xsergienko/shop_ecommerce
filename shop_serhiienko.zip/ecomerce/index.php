<?php include 'header.php'; ?>
<div class="container-fluid pt-5">


<div class="jumbotron mx-1 text-center">
    <h1>Welcome to Online Store!</h1>
     <h4>Our primary focus is on the customer. We grow by responding to their expectations and needs. Our greatest advantage is a wide range of products at affordable prices.</h4>
</div>

<!-- Carousel Start -->
<div class="container-fluid mb-3 d-flex justify-content-center">
    <div class="row" style="max-width: 85%; width: 900px;">
        <div class="col-lg-12">
            <div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel" data-interval="3000">
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                </ol>
                <div class="carousel-inner">
                    <!-- First item -->
                    <div class="carousel-item position-relative active" style="height: 430px;">
                        <img class="position-absolute w-100 h-100" src="img/msh2.jpg" style="object-fit: cover;">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <h1 class="text-primary mb-2 animate__animated animate__fadeInDown font-weight-bold" style="font-size: 2.5rem; line-height: 1.2; background-color: white; padding: 5px 10px; border-radius: 5px;">Products</h1>
                            <p class="mx-md-2 px-2 animate__animated animate__bounceIn text-primary font-weight-bold" style="line-height: 1.4; background-color: white; padding: 5px 10px; border-radius: 5px; font-size: 1rem;">Shop our diverse collection of goods and find the perfect fit for you.</p>
                            <a class="btn btn-primary py-2 px-4 mt-2 animate__animated animate__fadeInUp" href="view_products.php">Shop Now</a>
                        </div>
                    </div>
                    <!-- Second item -->
                    <div class="carousel-item position-relative" style="height: 430px;">
                        <img class="position-absolute w-100 h-100" src="img/cs3.jpg" style="object-fit: cover;">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <h1 class="text-primary mb-2 animate__animated animate__fadeInDown font-weight-bold" style="font-size: 2.5rem; line-height: 1.2; background-color: white; padding: 5px 10px; border-radius: 5px;">Support</h1>
                            <p class="mx-md-2 px-2 animate__animated animate__bounceIn text-primary font-weight-bold" style="line-height: 1.4; background-color: white; padding: 5px 10px; border-radius: 5px; font-size: 1rem;">Our dedicated support team is here to assist you with any questions or concerns you may have.</p>
                            <a class="btn btn-primary py-2 px-4 mt-2 animate__animated animate__fadeInUp" href="contact.php">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Carousel End -->
</div>

    
     <!-- Categories Start -->
    <div class="container-fluid" style="margin-top: -1px;">
    <h2 class="section-title position-relative text-uppercase mx-xl-5 mb-4 text-center"><span class="pr-3">Categories</span></h2>
    <div class="row px-xl-5 pb-3">
			<div class="col-lg-3 col-md-6 col-sm-12 pb-1 ">
            <a href="view_products.php?category=Electro" class="d-flex align-items-center bg-light ">      
                        <div class="overflow-hidden" style="width: 100px; height: 100px;">
                            <img class="img-fluid" src="img/product-6.jpg" alt="">
                        </div>
                        <div class="flex-fill pl-3">
                            <h6>Elektronika</h6>
                        </div>
            </a>
		    </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1 ">
            <a href="view_products.php?category=Hobby" class="d-flex align-items-center bg-light ">      
                        <div class="overflow-hidden" style="width: 100px; height: 100px;">
                            <img class="img-fluid" src="img/cat-2.jpg" alt="">
                        </div>
                        <div class="flex-fill pl-3">
                            <h6>Hobby</h6>
                        </div>
            </a>
		    </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1 ">
            <a href="view_products.php?category=Nábytok" class="d-flex align-items-center bg-light ">      
                        <div class="overflow-hidden" style="width: 100px; height: 100px;">
                            <img class="img-fluid" src="img/product-3.jpg" alt="">
                        </div>
                        <div class="flex-fill pl-3">
                            <h6>Nábytok</h6>
                        </div>
            </a>
		    </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1 ">
            <a href="view_products.php?category=Oblečenie" class="d-flex align-items-center bg-light ">      
                        <div class="overflow-hidden" style="width: 100px; height: 100px;">
                            <img class="img-fluid" src="img/cat-1.jpg" alt="">
                        </div>
                        <div class="flex-fill pl-3">
                            <h6>Oblečenie</h6>
                        </div>
            </a>
		    </div>
    </div>
</div>
<!-- Categories End -->
  
<div style="text-align: center; margin-top: 20px; margin-bottom: 20px;">
    <img src="img/at-home.jpg" alt="at home" class="img-fluid" style="height: 430px; display: inline-block;">
</div>

<!-- Featured Start -->
<div class="container-fluid pt-3">
		<div class="row px-xl-5 pb-3">
			<div class="col-lg-3 col-md-6 col-sm-12 pb-1">
				<div class="d-flex align-items-center bg-light mb-4" style="padding: 10px;">
					<h1 class="fa fa-check text-primary m-0 mr-2"></h1>
					<h5 class="font-weight-semi-bold m-0">Quality Product</h5>
				</div>

			</div>
			<div class="col-lg-3 col-md-6 col-sm-12 pb-1">
				<div class="d-flex align-items-center bg-light mb-4" style="padding: 10px;">
					<h1 class="fa fa-shipping-fast text-primary m-0 mr-2"></h1>
					<h5 class="font-weight-semi-bold m-0">Free Shipping</h5>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-12 pb-1">
				<div class="d-flex align-items-center bg-light mb-4" style="padding: 10px;">
					<h1 class="fas fa-exchange-alt text-primary m-0 mr-3"></h1>
					<h5 class="font-weight-semi-bold m-0">14-Day Return</h5>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-12 pb-1">
				<div class="d-flex align-items-center bg-light mb-4" style="padding: 10px;">
					<h1 class="fa fa-phone-volume text-primary m-0 mr-3"></h1>
					<h5 class="font-weight-semi-bold m-0">24/7 Support</h5>
				</div>
			</div>
		</div>
	</div>


<?php include 'footer.php'; ?>
