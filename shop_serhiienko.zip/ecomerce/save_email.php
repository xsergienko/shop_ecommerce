<?php
// Set the file path and name for saving the email addresses
$filename = "emails.txt";

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the email address from the form input
  $email = $_POST["email"];

  // Open the file in append mode
  $file = fopen($filename, "a");

  // Write the email address to the file
  fwrite($file, $email . "\n");

  // Close the file
  fclose($file);
  
  // Display a success message and stay on the same page
 echo "<script>alert('Email saved successfully!');</script>";

} // Redirect the user back to the index.php file
  header("Location: index.php");
//exit;