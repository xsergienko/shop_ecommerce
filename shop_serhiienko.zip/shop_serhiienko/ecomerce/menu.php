<?php
session_start();
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-light text-secondary py-3 pr-5 pl-5">
    <a class="navbar-brand" href="index.php"><i class="fas fa-shopping-cart text-primary mr-3">Online Store </i></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item"><a class="nav-link" href="view_products.php">Products</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Support Service</a></li>
            <?php if (isset($_SESSION['userid'])) { ?>
                <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
            <?php } ?>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == '1') { ?>
                <li class="nav-item"><a class="nav-link" href="add_product.php">Add product</a></li>
                <li class="nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
            <?php } ?>
        </ul>
        <ul class="navbar-nav">
            <?php if (isset($_SESSION['userid'])) { ?>
                <li class="nav-item"><span class="navbar-text">Hello, <?php echo $_SESSION['username']; ?></span></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            <?php } else { ?>
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
            <?php } ?>
        </ul>
    </div>
</nav>



