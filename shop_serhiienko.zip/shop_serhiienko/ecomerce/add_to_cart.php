<?php
session_start();
include 'db.php';

// Проверка авторизации пользователя
if (!isset($_SESSION['userid'])) {
    // Если пользователь не авторизован, перенаправляем его на страницу входа
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['add_to_cart'];
    $quantity = isset($_POST['quantity'][$product_id]) ? (int)$_POST['quantity'][$product_id] : 1;
    $user_id = $_SESSION['userid'];

    // Добавляем товар в корзину (таблицу order_items)
    $stmt = $conn->prepare("INSERT INTO order_items (user_id, product_id, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $user_id, $product_id, $quantity);
    $stmt->execute();
    $stmt->close();

    // Получаем ID последней вставленной записи в таблице order_items
    $order_item_id = $conn->insert_id;

    // Вписываем идентификатор записи из order_items в таблицу orders
    $stmt = $conn->prepare("INSERT INTO orders (order_id) VALUES (?)");
    $stmt->bind_param("i", $order_item_id);
    $stmt->execute();
    $stmt->close();

    // Перенаправляем пользователя на страницу с товарами после добавления в корзину
    header("Location: view_products.php");
    exit();
}
?>
