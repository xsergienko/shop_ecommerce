
<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set the file path and name for saving the support messages
$filename = "support.txt";

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Open the file in append mode
    $file = fopen($filename, "a");
    if ($file) {
        // Write the data to the file
        fwrite($file, "Name: " . $name . "\n");
        fwrite($file, "Email: " . $email . "\n");
        fwrite($file, "Subject: " . $subject . "\n");
        fwrite($file, "Message: " . $message . "\n");
        fwrite($file, "----------------------------------------\n");
        
        // Close the file
        fclose($file);

        // Display a success message using JavaScript and then redirect
        echo "<script>alert('Your message has been sent successfully!'); window.location.href = 'index.php';</script>";
    } else {
        echo "Error opening file: " . error_get_last()['message'];
    }
} else {
    // If the form was not submitted, redirect to the contact form
    header("Location: contact.php");
    exit;
}
?>

