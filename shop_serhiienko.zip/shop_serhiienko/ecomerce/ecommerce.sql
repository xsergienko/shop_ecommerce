-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 27 2024 г., 14:04
-- Версия сервера: 8.0.30
-- Версия PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ecommerce`
--

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `order_id`, `created_at`) VALUES
(16, 16, '2024-05-25 23:31:43'),
(17, 17, '2024-05-25 23:31:44'),
(18, 18, '2024-05-26 21:46:25'),
(20, 20, '2024-05-26 21:46:27'),
(22, 22, '2024-05-26 21:46:30'),
(23, 23, '2024-05-27 10:17:00'),
(24, 24, '2024-05-27 10:17:06'),
(25, 25, '2024-05-27 10:17:09'),
(26, 26, '2024-05-27 10:17:23'),
(27, 27, '2024-05-27 10:17:29');

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `user_id`, `product_id`, `quantity`) VALUES
(16, 1, 1, 1),
(17, 1, 2, 1),
(18, 8, 1, 1),
(20, 8, 3, 1),
(22, 8, 5, 1),
(23, 3, 3, 1),
(24, 3, 8, 1),
(25, 3, 11, 1),
(26, 3, 4, 3),
(27, 3, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('Electro','Nábytok','Oblečenie','Hobby') NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `description`, `price`) VALUES
(1, 'Chladnička Samsung', 'Electro', 'Chladnička – s mrazničkou, energetická trieda B, objem chladničky 273 l.', '724.00'),
(2, 'Dámske tričko XS', 'Oblečenie', 'Dámske tričko QUECHUA s krátkym rukávom na horskú turistiku.', '7.00'),
(3, 'Mimoriadne priedušná detská obuv', 'Oblečenie', 'Tenisky z radu PLAY boli navrhnuté s ohľadom na vývoj a pohodlie detí. ', '25.00'),
(4, 'Pánske boxerkové plavky', 'Oblečenie', 'Pánske boxerkové plavky Yoke modro-čierne (M).', '9.00'),
(5, 'Kreslo ušiak Deana', 'Nábytok', 'Kreslo ušiak Deana - zelená.', '210.00'),
(6, 'Slúchadlá Apple AirPods Pro', 'Electro', 'Bezdrôtové slúchadlá – s mikrofónom, True Wireless, štuple, aktívne potlačenie hluku.', '250.00'),
(7, 'Televízor Samsung', 'Electro', 'Televízor SMART Neo QLED, 165cm, 4K Ultra HD, 100Hz, Mini LED, HDR10, HDR10+/', '1000.00'),
(8, 'Príručný stolík Mariffa', 'Nábytok', 'Príručný stolík Mariffa - čierna / prírodná.', '30.00'),
(9, 'TV stolík SENSO ', 'Nábytok', 'TV stolík SENSO E RTV187 - béžová.', '180.00'),
(10, 'Maliarsky stojan ', 'Hobby', 'Maliarsky stojan ateliérový MONET.\r\n', '30.00'),
(11, 'Basketbalová lopta', 'Hobby', 'Detská basketbalová lopta, vhodná pre športové aktivity.\r\n', '7.00'),
(12, 'Horský bicykel', 'Hobby', 'Horský bicykel Explore 500 29\" čierny.', '500.00');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` int DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `phone`, `role`) VALUES
(1, 'Mark', 'Newberg', 'newberg@stuba.sk', '$2y$10$9s9OggtXh/DZddRGG1ue0ulhMCLqi/LGGVfj8TZM3LI6zkqFn4U5O', '123123123123', 1),
(3, 'Mary', 'Pinn', 'pinn@stuba.sk', '$2y$10$kvk7hGiBv.zVhbD56p3n0u1Mrn4rdeSUfjr6LaS1lg0MbNkixgfD.', '', 2),
(4, 'John', 'Watson', 'watson@stuba.sk', '$2y$10$QxwX/QnRBhj4F9unNxHC.uvlYQOwdL5kNGf/eDGUROwh7SuzlFxuq', '', 2),
(5, 'Sherlock', 'Holmes', 'xholmes@stuba.sk', '$2y$10$V7qEE0fEf6zP/u4lGyz.YOdbdl2oCKpuL2fEEtKWJq6fosSLvvuP2', '', 2),
(6, 'Mika', 'Nelson', 'nelson@stuba.sk', '$2y$10$L2HPht6Wm1yzfxQWD2DBLeukJghanh5YlebXNVOjcIpAM67W0ODUi', '', 2),
(7, 'Kate', 'Lilysberg', 'lily@stuba.sk', '$2y$10$MjbL.TK34pOi9vE6adfu4O3ATXLVW9v8KRIROp2YQIdvFgxrjSrOm', '0987860325', 2),
(8, 'Sofiia ', 'Serhiienko', 'xsergienko@stuba.sk', '$2y$10$acHrQqDr0OGy5N3EfhDP4OVS5fqSGRfVLa4k5w8ROPAL9MBCK0u9i', '', 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `order_items_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
