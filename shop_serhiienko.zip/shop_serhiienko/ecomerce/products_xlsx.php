<?php
session_start();

// Include autoloader
require 'vendor/autoload.php';
include 'db.php';
$user_id = $_SESSION['userid'];

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Spreadsheet styling
$styleArray = [
    'font' => [
        'bold' => true,
    ],
    'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        'color' => [
            'argb' => 'FFFFFF00',
        ]
    ],
];

// Create new Spreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// First row headers
$sheet->setCellValue('A1', 'Name');
$sheet->getStyle('A1')->getFont()->setBold(true);

$sheet->setCellValue('B1', 'Price(€)');
$sheet->getStyle('B1')->getFont()->setBold(true);

$sheet->setCellValue('C1', 'Quantity');
$sheet->getStyle('C1')->getFont()->setBold(true);

$sheet->setCellValue('D1', 'Total(€)');
$sheet->getStyle('D1')->getFont()->setBold(true);

$r = 1; // Row counter starting from the second row
// Fetch data from the database
$sql = "SELECT order_items.id, products.name, products.price, order_items.quantity
        FROM order_items
        INNER JOIN products ON order_items.product_id = products.id
        WHERE order_items.user_id = $user_id";
$result = $conn->query($sql);
$total_price = 0; // Initialize the total price variable

if (mysqli_num_rows($result) > 0) { // If there is at least one record

    while ($row = mysqli_fetch_assoc($result)) { // Fetch data from the database
        $name = $row['name'];
        $price = $row['price'];
        $quantity = $row['quantity'];
        $total = $price * $quantity;

    $r++;
    $sheet->setCellValue('A' . $r, $name);
    $sheet->setCellValue('B' . $r, number_format($price, 2));
    $sheet->setCellValue('C' . $r, $quantity);
    $sheet->setCellValue('D' . $r, number_format($total, 2));

    $total_price += $total; // Add the total price of each item to the total price
}}
$sheet->setCellValue('F' . $r, 'Total: ' . number_format($total_price, 2));
$sheet->getStyle('F' . $r)->getFont()->setBold(true);


// Redirect output to a client's web browser (Xlsx)
header('Content-Type: application/vnd.openxmlformats- officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="cart.xlsx"');
header('Cache-Control: max-age=0');

$writer = PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
$writer->save('php://output');
exit;
