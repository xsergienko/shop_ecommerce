<?php include 'header.php'; ?>

<?php
session_start();

if (!isset($_SESSION['userid']) || $_SESSION['role'] != '1') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'db.php';

    $name = $_POST['name'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $sql = "INSERT INTO products (name, category, description, price) VALUES ('$name', '$category', '$description', '$price')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Product added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<div class="container narrow-form mt-3" style="max-width: 800px; margin: 0 auto;">

<form method="post" action="add_product.php">
    <div class="form-group mt-3">
        <label for="name">Product Name:</label>
        <input type="text" class="form-control" id="name" name="name" required>
    </div>
    <div class="form-group">
        <label for="category">Category:</label>
        <select class="form-control" id="category" name="category" required>
            <option value="Electro">Electro</option>
            <option value="Nábytok">Nábytok</option>
            <option value="Oblečenie">Oblečenie</option>
            <option value="Hobby">Hobby</option>
        </select>
    </div>
    <div class="form-group">
        <label for="description">Description:</label>
        <textarea class="form-control" id="description" name="description" required></textarea>
    </div>
    <div class="form-group">
        <label for="price">Price without VAT (€):</label>
        <input type="number" step="0.01" class="form-control" id="price" name="price" required>
    </div>

    <div class="container text-center">
    <div class="row">     
    <div class="col-md-12">
    <button type="submit" class="btn btn-lg btn-primary" style="margin: 10px;">Add Product</button>
    </div> </div> </div>
</form>
</div>

<?php include 'footer.php'; ?>
