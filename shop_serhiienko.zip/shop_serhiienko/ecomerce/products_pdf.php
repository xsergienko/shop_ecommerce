<?php
session_start();
include 'db.php';


// Include autoloader
require 'vendor/autoload.php';

// Reference the Dompdf namespace
use Dompdf\Dompdf;

// Instantiate and use the Dompdf class
$dompdf = new Dompdf();

$user_id = $_SESSION['userid'];


$text = "
<style>
* {font-family: DejaVu Sans;}             
td, th {padding: 2px 10px;}
th {background: #ffffaa}
</style>

<h1>Your Cart</h1>
<table>
<tr> 
<th>Name</th>
<th>Price(€)</th>
<th>Quantity</th>
<th>Total(€)</th>
</tr>"; // diakritika DejaVu Sans

// Запрос для получения товаров в корзине текущего пользователя
$sql = "SELECT order_items.id, products.name, products.price, order_items.quantity
        FROM order_items
        INNER JOIN products ON order_items.product_id = products.id
        WHERE order_items.user_id = $user_id";
$result = $conn->query($sql);
$total_price = 0; // Initialize the total price variable

if (mysqli_num_rows($result) > 0) { // If there is at least one record

    while ($row = mysqli_fetch_assoc($result)) { // Fetch data from the database
        $name = $row['name'];
        $price = $row['price'];
        $quantity = $row['quantity'];
        $total = $price * $quantity;

        // Append a row to the table
        $text .= "<tr>";  // .= adds to $text the tag tr
        $text .= "<td>$name</td>";
        $text .= "<td>" . number_format($price, 2) . "</td>";
        $text .= "<td>$quantity</td>";
        $text .= "<td>" . number_format($total, 2) . "</td>";
        $text .= "</tr>";
        
        $total_price += $total; // Add the total price of each item to the total price
    }

}
$text .= "</table>";
$text .= "<h4> Total Price: " . number_format($total_price, 2) . " €</h4>";

$dompdf->loadHtml($text);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'portrait'); // portrait/landscape

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
$dompdf->stream('cart.pdf');
?>