<?php include 'header.php'; ?>
<?php
session_start();
include 'db.php';
?>

<!-- Contact Start -->
<div class="container-fluid">
        
<!-- zaciatok formulara -->
<form action="support.php" method="post">
    <h2 class="section-title position-relative mt-3 mx-xl-5 mb-3"><span class="pr-3">Customer Service</span></h2>
    <div class="row px-xl-5">
        <div class="col-lg-7 mb-5">
            <div class="contact-form p-30">
                <div id="success"></div>
                <div class="control-group">
                    <label for="name">First Name and Last Name:</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="For example, Albert Einstein" required="required" data-validation-required-message="Please enter your name" />
                    <p class="help-block text-danger"></p>
                </div>
                <div class="control-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="For example, xeinstein@stuba.sk" required="required" data-validation-required-message="Please enter your email" />
                    <p class="help-block text-danger"></p>
                </div>
                <div class="control-group">
                    <label for="subject">Subject:</label>
                    <input type="text" class="form-control" id="subject" name="subject" placeholder="Title of your problem" required="required" data-validation-required-message="Please enter a subject" />
                    <p class="help-block text-danger"></p>
                </div>
                <div class="control-group">
                    <label for="message">Description:</label>
                    <textarea class="form-control" rows="8" id="message" name="message" placeholder="Describe your issue or question here" required="required" data-validation-required-message="Please describe your issue or question"></textarea>
                    <p class="help-block text-danger"></p>
                </div>
                <div class="container text-center">
                    <div class="row">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-lg btn-success" style="margin: 10px;">Submit</button>
                            <button type="reset" class="btn btn-primary btn-lg" style="margin: 10px;">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-5 mb-5">
            <div class="bg-light p-30 mb-30">
                <iframe style="width: 100%; height: 250px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2660.8911773156246!2d17.13191911566425!3d48.158933179224495!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476c8d151d4d4bd5%3A0xf3e3f8ad17aae349!2sRa%C4%8Dianska%20103%2C%2083102%20Bratislava%2C%20Slovensko!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="p-30 mb-3">
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>Račianska 103, Bratislava, Slovensko</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>xsergienko@stuba.sk</p>
                <p class="mb-2"><i class="fa fa-phone-alt text-primary mr-3"></i>+421 333 6789</p>
            </div>
        </div>
    </div>
</form>

<!-- koniec formulara -->  
</div>
<!-- Contact End -->


<?php include 'footer.php'; ?>
