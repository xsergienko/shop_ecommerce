<?php include 'header.php'; ?>

<?php
session_start();

if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userid = $_SESSION['userid'];
    $product_ids = $_POST['product_ids'];
    $quantities = $_POST['quantities'];

    $sql = "INSERT INTO orders (user_id) VALUES ('$userid')";
    
    if ($conn->query($sql) === TRUE) {
        $order_id = $conn->insert_id;
        foreach ($product_ids as $key => $product_id) {
            $quantity = $quantities[$key];
            $sql = "INSERT INTO order_items (order_id, product_id, quantity) VALUES ('$order_id', '$product_id', '$quantity')";
            $conn->query($sql);
        }
        echo "Order placed successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<form method="post" action="place_order.php">
    <div class="form-group">
        <label for="product_ids">Product IDs (comma separated):</label>
        <input type="text" class="form-control" id="product_ids" name="product_ids[]" required>
    </div>
    <div class="form-group">
        <label for="quantities">Quantities (comma separated):</label>
        <input type="text" class="form-control" id="quantities" name="quantities[]" required>
    </div>
    <button type="submit" class="btn btn-primary">Place Order</button>
</form>

<?php include 'footer.php'; ?>
