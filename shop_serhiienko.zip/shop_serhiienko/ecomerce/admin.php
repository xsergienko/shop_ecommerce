<?php include 'header.php'; ?>

<?php
session_start();

if (!isset($_SESSION['userid']) || $_SESSION['role'] != '1') {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Проверка на успешное выполнение запроса и обработка ошибок
function executeQuery($conn, $query) {
    $result = $conn->query($query);
    if (!$result) {
        die("Query failed: " . $conn->error);
    }
    return $result;
}

// Общее количество заказов
$sql_total_orders = "SELECT COUNT(*) as total_orders FROM orders";
$result_total_orders = executeQuery($conn, $sql_total_orders);
$row_total_orders = $result_total_orders->fetch_assoc();
$total_orders = $row_total_orders['total_orders'];

// Количество заказов по годам
$sql_orders_per_year = "SELECT YEAR(created_at) as year, COUNT(*) as total FROM orders GROUP BY YEAR(created_at)";
$result_orders_per_year = executeQuery($conn, $sql_orders_per_year);

// Общее количество пользователей
$sql_total_users = "SELECT COUNT(*) as total_users FROM users";
$result_total_users = executeQuery($conn, $sql_total_users);
$row_total_users = $result_total_users->fetch_assoc();
$total_users = $row_total_users['total_users'];

$conn->close();
?>

<div class="container mt-3">
    <h2>Admin Dashboard</h2>
    <p>Total Orders: <?php echo $total_orders; ?></p>
    <p>Total Users: <?php echo $total_users; ?></p>

    <h3>Orders per Year</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Year</th>
                <th>Total Orders</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row_orders_per_year = $result_orders_per_year->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row_orders_per_year['year']; ?></td>
                    <td><?php echo $row_orders_per_year['total']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
